<?php
//error_reporting(1);
//mysql_connect('localhost', 'root', '','vote') or die(mysql_error());
//mysql_select_db('vote') or die(mysql_error());

$db=new mysqli('localhost','root','','vote') or die(mysql_error())

?>
